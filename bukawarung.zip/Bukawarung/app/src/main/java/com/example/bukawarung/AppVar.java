package com.example.bukawarung;

public class AppVar {
    public static final String LOGIN_URL = "http://192.168.43.144/bukawarung/login.php";
    //Keys for email and password as defined in our $_POST['key'] in login.ph
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";
    //If server response is equal to this that means login is successful
    public static final String LOGIN_SUCCESS = "success";
}
