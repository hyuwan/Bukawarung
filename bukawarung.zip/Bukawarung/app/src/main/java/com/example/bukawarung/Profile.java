package com.example.bukawarung;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends AppCompatActivity {

    private TextView bukaWar;
    private LinearLayout wa, fac, twit, ig, www;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        //instantiasi
        bukaWar = findViewById(R.id.bukawar);
        //intent ke main
        bukaWar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Profile.this, MainActivity.class);
                startActivity(i);
            }
        });

        //instantiasi
        wa = findViewById(R.id.wa);
        fac = findViewById(R.id.fac);
        twit = findViewById(R.id.twit);
        ig = findViewById(R.id.ig);
        www = findViewById(R.id.www);
        //wa
        wa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Profile.this, "WhatsApp 089688177247", Toast.LENGTH_LONG).show();
            }
        });
        //fac
        fac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Profile.this, "Facebook bukawarung16", Toast.LENGTH_LONG).show();
            }
        });
        //twit
        twit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Profile.this, "Twitter bukawarungnew16", Toast.LENGTH_LONG).show();
            }
        });
        //ig
        ig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Profile.this, "Instagram bukawarungnew16", Toast.LENGTH_LONG).show();
            }
        });
        //www
        www.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Profile.this, "Website www.bukawarung.co.id", Toast.LENGTH_LONG).show();
            }
        });

    }
}
