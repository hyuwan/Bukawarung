package com.example.bukawarung;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    private EditText editTextEmail;
    private EditText editTextPass;
    private Context context;
    private AppCompatButton buttonLogin;
    private ProgressDialog pDialog;
    private TextView regist;
    private TextView home;
    private ImageView bw;
    SharedPreferences preferences;

    public static final String KEYPREF = "Key Preferences";
    public static final String KEYUSERNAE = "Key Username";
    public static final String KEYPASSWORD = "Key Password";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        context = Login.this;

        //intent login ke main
        //instantiasi
        home = findViewById(R.id.homeLogin);
        bw = findViewById(R.id.bwLogin);
        //intent ke main
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this, MainActivity.class);
                startActivity(i);
            }
        });
        bw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this, MainActivity.class);
                startActivity(i);
            }
        });


        //inisialisasi
        pDialog = new ProgressDialog(context);

        editTextEmail = (EditText)findViewById(R.id.editTextEmail);
        editTextPass = (EditText)findViewById(R.id.editTextPassword);
        regist = findViewById(R.id.register);

        preferences = getSharedPreferences(KEYPREF, Context.MODE_PRIVATE);
        if (preferences.contains(KEYUSERNAE) && preferences.contains(KEYPASSWORD)){
            editTextEmail.setText(preferences.getString(KEYUSERNAE,""));
            editTextPass.setText(preferences.getString(KEYPASSWORD,""));
        }
        buttonLogin = (AppCompatButton)findViewById(R.id.buttonLogin);

        //fungsi untuk berpindah halaman ke halaman setelah login
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        //fungsi untuk berpindah ke halaman register
        regist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this, Register.class);
                startActivity(i);
            }
        });

    }

    private void login() {
        //mengambil data dari id ke variabel atau field
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPass.getText().toString().trim();
        SharedPreferences.Editor editor = preferences.edit();

        editor.putString(KEYUSERNAE, email);
        editor.putString(KEYPASSWORD, password);

        editor.apply();
        //proses ketika login berjalan
        pDialog.setMessage("Login Process . . .");
        //untuk menampilkan pesan diatas
        showDialog();

        //merequest method post dari AppVar
        StringRequest stringRequest = new StringRequest(Request.Method.POST, AppVar.LOGIN_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //jika login sucess maka akan diarahkan ke method hideDialog dan gotoFormActivity
                if (response.contains(AppVar.LOGIN_SUCCESS)) {
                    hideDialog();
                    gotoFormActivity();
                } else {
                    //jika email dan password belum diisi maka akan muncul
                    hideDialog();
                    Toast.makeText(context, "Invalid email and password!", Toast.LENGTH_LONG).show();
                }
            }
        },      // jika tidak terhubung ke server
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideDialog();
                        Toast.makeText(context, "The server unreachable", Toast.LENGTH_LONG).show();
                    }
                })
        {
            //memasukan value menggunakan key ke field atau variabel
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put(AppVar.KEY_EMAIL, email);
                params.put(AppVar.KEY_PASSWORD, password);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
    //method untuk berpindah halaman setelah login berhasil
    private void gotoFormActivity(){
        Intent i = new Intent(Login.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();;
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

}
