package com.example.bukawarung;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class FormOrder extends AppCompatActivity {

    private TextView hargabarang;
    private TextView ongkir;
    private TextView total;
    private TextView namabarang;
    private String getV_hargabarang;
    private String get_ongkir;
    private String get_namabarang;

    private Button salin1;
    private Button salin2;
    private Button salin3;
    private Button salin4;
    private Button btnform;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_order);

        hargabarang = findViewById(R.id.hargaBarang);
        ongkir = findViewById(R.id.ongkir);
        namabarang = findViewById(R.id.namaBarang);
        total = findViewById(R.id.total);
        salin1 = findViewById(R.id.salin1);
        salin2 = findViewById(R.id.salin2);
        salin3 = findViewById(R.id.salin3);
        salin4 = findViewById(R.id.salin4);
        btnform = findViewById(R.id.btnForm);

        salin1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast();
            }
        });

        salin2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast();
            }
        });

        salin3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast();
            }
        });

        salin4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast();
            }
        });

        btnform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FormOrder.this, MainActivity.class);
                startActivity(i);
            }
        });


        Bundle b = getIntent().getExtras();
        get_namabarang = b.getString("nama");
        getV_hargabarang = b.getString("harga");
        get_ongkir = b.getString("ongkir");
        namabarang.setText("Nama : "+ get_namabarang);
        ongkir.setText("Ongkir : Rp."+get_ongkir);
        hargabarang.setText("Harga : Rp."+getV_hargabarang);

        double har = Double.parseDouble(getV_hargabarang);
        double ong = Double.parseDouble(get_ongkir);
        double tot = (har+ong);

        total.setText("Total bayar : Rp."+tot);


    }
    public void toast(){
        Toast.makeText(FormOrder.this, "Berhasil disalin!", Toast.LENGTH_LONG).show();
    }
}
