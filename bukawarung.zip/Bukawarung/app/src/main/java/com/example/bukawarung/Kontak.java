package com.example.bukawarung;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Kontak extends AppCompatActivity {

    private TextView bukawar;
    private LinearLayout wa;
    private LinearLayout wats;
    private LinearLayout face;
    private LinearLayout faceb;
    private LinearLayout twiter;
    private LinearLayout tw;
    private LinearLayout igee;
    private LinearLayout igeee;
    private LinearLayout telepon;
    private LinearLayout web;
    private LinearLayout website;
    private LinearLayout mail;
    private LinearLayout emailact;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kontak);
        context = Kontak.this;

        //instantiasi
        bukawar = findViewById(R.id.bukawarKontak);
        //intent ke main
        bukawar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Kontak.this, MainActivity.class);
                startActivity(i);
            }
        });

        wa = findViewById(R.id.whatsapp);
        wa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String contact = "+628 2120913564";
                String url = "https://api.whatsapp.com/send?phone="+contact;
                try{
                    PackageManager pm = context.getPackageManager();
                    pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);

                } catch (PackageManager.NameNotFoundException e){
                    Toast.makeText(context, "Whatsapp not installed your phone",Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });

        wats = findViewById(R.id.wats);
        wats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String contact = "+628 2120913564";
                String url = "https://api.whatsapp.com/send?phone="+contact;
                try{
                    PackageManager pm = context.getPackageManager();
                    pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);

                } catch (PackageManager.NameNotFoundException e){
                    Toast.makeText(context, "Whatsapp not installed your phone",Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });

        face = findViewById(R.id.face);
        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keFacebook("2170665806541743");
            }
        });

        faceb = findViewById(R.id.faceb);
        faceb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keFacebook("2170665806541743");
            }
        });

        //instantiasi twiter
        twiter = findViewById(R.id.twiter);
        //intent ke main
        twiter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Twitter belum ada !", Toast.LENGTH_LONG).show();
            }
        });
        //instantiasi twiter
        tw = findViewById(R.id.tw);
        //intent ke main
        tw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Twitter belum ada !", Toast.LENGTH_LONG).show();
            }
        });

        //instantiasi ig
        igee = findViewById(R.id.igee);
        //intent ke main
        igee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             keInstagram();
            }
        });
        //instantiasi ig
        igeee = findViewById(R.id.igeee);
        //intent ke main
        igeee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             keInstagram();

            }
        });


        //instantiasi telepon
        telepon = findViewById(R.id.telepon);
        //toast
        telepon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Toast.makeText(context, "Telepon bukawarung", Toast.LENGTH_LONG).show();

            }
        });

        //instantiasi email
        mail = findViewById(R.id.mail);
        //intent ke main
        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               keEmail();

            }
        });

        //instantiasi email
        emailact = findViewById(R.id.emailact);
        //intent ke main
        emailact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keEmail();
            }
        });


        //instantiasi web
        web = findViewById(R.id.web);
        //intent ke main
        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keWebsiter();
            }
        });

        //instantiasi web
        website = findViewById(R.id.website);
        //intent ke main
        website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keWebsiter();
            }
        });


    }

    //link facebook
    public void keFacebook(String id){
        try{
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/" + id));
            startActivity(i);
        }catch (ActivityNotFoundException e){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.facebook.com/" + id));
            startActivity(intent);

        }
    }

    public void keInstagram(){
        Uri uri = Uri.parse("http://instagram.com/_u/hyuwanew");
        Intent likeIng = new Intent(Intent.ACTION_VIEW, uri);

        likeIng.setPackage("com.instagram.android");

        try {
            startActivity(likeIng);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://instagram.com/hyuwanew")));
        }
    }

    public void keEmail(){
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, "hermawanwahyu47023@gmail.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
        intent.putExtra(Intent.EXTRA_TEXT, "I'm email body.");

        startActivity(Intent.createChooser(intent, "Send Email"));
    }

    public void keWebsiter(){
        String url = "http://www.bukalapak.com";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

}
