package com.example.bukawarung;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Form extends AppCompatActivity {
    private EditText nama, description, gambar;
    private Button btn_form;
    private ProgressBar loading;
    private TextView homes;
    private static String URL_REGIST     = "http://192.168.43.144/bukawarung/form.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        loading = findViewById(R.id.loadingForm);
        nama = findViewById(R.id.editBarang);
        description = findViewById(R.id.editDescription);
        gambar = findViewById(R.id.editGambar);
        btn_form = findViewById(R.id.buttonForm);
        homes = findViewById(R.id.homeForm);

        homes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Form.this, MainActivity.class);
                startActivity(i);
            }
        });



        btn_form.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                form();
            }
        });
    }
    public void form(){
        loading.setVisibility(View.VISIBLE);
        btn_form.setVisibility(View.GONE);

        final String nama = this.nama.getText().toString().trim();
        final String description = this.description.getText().toString().trim();
        final String gambar = this.gambar.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGIST, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");

                    if (success.equals("1")){
                        Toast.makeText(Form.this, "Register Success!", Toast.LENGTH_SHORT).show();
                        Intent i =new Intent(Form.this, MainActivity.class);
                        startActivity(i);
                    }
                } catch (JSONException e){
                    e.printStackTrace();
                    Toast.makeText(Form.this, "Register Error!" + e.toString(), Toast.LENGTH_SHORT).show();
                    loading.setVisibility(View.GONE);
                    btn_form.setVisibility(View.VISIBLE);
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Form.this, "Register Error!" + error.toString(), Toast.LENGTH_SHORT).show();
                        loading.setVisibility(View.GONE);
                        btn_form.setVisibility(View.VISIBLE);

                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("nama", nama);
                params.put("description", description);
                params.put("gambar", gambar);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
